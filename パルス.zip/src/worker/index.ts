import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Enable CORS for all routes
app.use("*", cors({
  origin: ["http://localhost:5173"],
  credentials: true,
}));

// OAuth routes
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Channel routes
app.get("/api/channels", authMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM channels ORDER BY is_general DESC, name ASC"
  ).all();

  return c.json(results);
});

app.post("/api/channels", authMiddleware, async (c) => {
  const { name, description } = await c.req.json();
  
  if (!name || name.trim().length === 0) {
    return c.json({ error: "Channel name is required" }, 400);
  }

  const normalizedName = name.toLowerCase().replace(/[^a-z0-9-_]/g, '-');
  
  try {
    const result = await c.env.DB.prepare(
      "INSERT INTO channels (name, description, created_at, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
    ).bind(normalizedName, description || null).run();

    const channel = await c.env.DB.prepare(
      "SELECT * FROM channels WHERE id = ?"
    ).bind(result.meta.last_row_id).first();

    return c.json(channel, 201);
  } catch (error) {
    return c.json({ error: "Channel name already exists" }, 409);
  }
});

// Message routes
app.get("/api/channels/:channelId/messages", authMiddleware, async (c) => {
  const channelId = c.req.param("channelId");
  const limit = parseInt(c.req.query("limit") || "50");
  
  const { results } = await c.env.DB.prepare(`
    SELECT m.*, u.google_user_data as user_data
    FROM messages m
    LEFT JOIN (
      SELECT DISTINCT user_id, google_user_data 
      FROM messages 
      WHERE channel_id = ?
    ) u ON m.user_id = u.user_id
    WHERE m.channel_id = ?
    ORDER BY m.created_at DESC
    LIMIT ?
  `).bind(channelId, channelId, limit).all();

  // Reverse to show oldest first
  return c.json(results.reverse());
});

app.post("/api/channels/:channelId/messages", authMiddleware, async (c) => {
  const channelId = c.req.param("channelId");
  const { content } = await c.req.json();
  const user = c.get("user");
  
  if (!content || content.trim().length === 0) {
    return c.json({ error: "Message content is required" }, 400);
  }

  // Store user data with the message for display purposes
  await c.env.DB.prepare(
    "INSERT INTO messages (channel_id, user_id, content, created_at, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
  ).bind(channelId, user!.id, content.trim()).run();

  const message = await c.env.DB.prepare(`
    SELECT * FROM messages 
    WHERE channel_id = ? AND user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 1
  `).bind(channelId, user!.id).first();

  // Add user data to the response
  return c.json({
    ...message,
    user_data: user!.google_user_data
  }, 201);
});

export default app;
